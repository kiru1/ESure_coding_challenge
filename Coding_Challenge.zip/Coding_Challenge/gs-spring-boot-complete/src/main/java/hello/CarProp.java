package hello;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"brand",
"model",
"fuel",
"doors",
"colour"
})
public class CarProp {

@JsonProperty("brand")
private String brand;
@JsonProperty("model")
private String model;
@JsonProperty("fuel")
private String fuel;
@JsonProperty("doors")
private Integer doors;
@JsonProperty("colour")
private String colour;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("brand")
public String getBrand() {
return brand;
}

@JsonProperty("brand")
public void setBrand(String brand) {
this.brand = brand;
}

@JsonProperty("model")
public String getModel() {
return model;
}

@JsonProperty("model")
public void setModel(String model) {
this.model = model;
}

@JsonProperty("fuel")
public String getFuel() {
return fuel;
}

@JsonProperty("fuel")
public void setFuel(String fuel) {
this.fuel = fuel;
}

@JsonProperty("doors")
public Integer getDoors() {
return doors;
}

@JsonProperty("doors")
public void setDoors(Integer doors) {
this.doors = doors;
}

@JsonProperty("colour")
public String getColour() {
return colour;
}

@JsonProperty("colour")
public void setColour(String colour) {
this.colour = colour;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}